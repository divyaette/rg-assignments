const express = require('express')
const morgan = require('morgan')
const bodyParser = require('body-parser')
const routes = require('./routes')

const app = express();

app.use(morgan('dev'));                   
app.use(bodyParser.json());            
app.use(bodyParser.urlencoded({ extended: false }));

routes(app);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server started on port ${PORT}`);
});